package com.example.rice;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class PredictionWithTimestampResponse {

    @SerializedName("detected_disease")  // Matches "detected_disease" in the JSON
    private String prediction;

    @SerializedName("average_confidence")  // Matches "average_confidence" in the JSON
    private double average_confidence;

    @SerializedName("pesticides")  // Matches "pesticides" in the JSON
    private String pesticides;

    @SerializedName("precautions")  // Matches "precautions" in the JSON
    private String precautions;

    @SerializedName("timestamp")  // Matches "timestamp" in the JSON
    private String timestamp;

    public String getPrediction() {
        return prediction;
    }

    public double getAverage_confidence() {
        return average_confidence;
    }

    public String getPesticides() {
        return pesticides;
    }

    public String getPrecautions() {
        return precautions;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
