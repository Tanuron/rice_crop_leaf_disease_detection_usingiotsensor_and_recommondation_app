package com.example.rice;

import java.util.List;

import retrofit2.Call;
import okhttp3.MultipartBody;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiService {

    @Multipart
    @POST("/api/predict/")  // Correct backend URL
    Call<PredictionResponse> uploadImageAndGetPrediction(@Part MultipartBody.Part file);

    // Endpoint to fetch all stored predictions
    @GET("api/get_predictions/")
    Call<List<PredictionWithTimestampResponse>> getPredictionsWithTimestamp(); // Fetch predictions from the backend
}
