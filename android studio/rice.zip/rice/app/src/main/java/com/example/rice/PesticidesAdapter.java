package com.example.rice;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PesticidesAdapter extends TypeAdapter<Object> {

    @Override
    public void write(JsonWriter out, Object value) throws IOException {
        // Handle serialization if needed (optional).
    }

    @Override
    public Object read(JsonReader in) throws IOException {
        // Check if the field is a string
        if (in.peek() == com.google.gson.stream.JsonToken.STRING) {
            String str = in.nextString();
            List<String> list = new ArrayList<>();
            list.add(str); // Add the string as the only item in the list
            return list;
        }

        // If the field is an array, deserialize it as a List<String>
        else if (in.peek() == com.google.gson.stream.JsonToken.BEGIN_ARRAY) {
            List<String> list = new ArrayList<>();
            in.beginArray();
            while (in.hasNext()) {
                list.add(in.nextString());
            }
            in.endArray();
            return list;
        }

        // Return null if the field is not a string or array
        return null;
    }

    // Method to parse a JSON string response (if needed outside TypeAdapter)
    public void parseJsonResponse(String jsonResponse) {
        JsonElement element = JsonParser.parseString(jsonResponse);

        // Check if it's a JsonObject or JsonArray
        if (element.isJsonObject()) {
            JsonObject jsonObject = element.getAsJsonObject();

            // Example: Get pesticides key and process it
            JsonElement pesticidesElement = jsonObject.get("pesticides");
            if (pesticidesElement != null) {
                if (pesticidesElement.isJsonArray()) {
                    // Handle array
                    JsonArray pesticidesArray = pesticidesElement.getAsJsonArray();
                    for (JsonElement pesticide : pesticidesArray) {
                        System.out.println("Pesticide: " + pesticide.getAsString());
                    }
                } else if (pesticidesElement.isJsonPrimitive() && pesticidesElement.getAsJsonPrimitive().isString()) {
                    // Handle string
                    System.out.println("Pesticide: " + pesticidesElement.getAsString());
                } else {
                    System.out.println("Unexpected type for 'pesticides'.");
                }
            } else {
                System.out.println("'pesticides' key not found.");
            }

            // Example: Get precautions key and process it
            JsonElement precautionsElement = jsonObject.get("precautions");
            if (precautionsElement != null) {
                if (precautionsElement.isJsonArray()) {
                    // Handle array
                    JsonArray precautionsArray = precautionsElement.getAsJsonArray();
                    for (JsonElement precaution : precautionsArray) {
                        System.out.println("Precaution: " + precaution.getAsString());
                    }
                } else if (precautionsElement.isJsonPrimitive() && precautionsElement.getAsJsonPrimitive().isString()) {
                    // Handle string
                    System.out.println("Precaution: " + precautionsElement.getAsString());
                } else {
                    System.out.println("Unexpected type for 'precautions'.");
                }
            } else {
                System.out.println("'precautions' key not found.");
            }
        } else if (element.isJsonArray()) {
            JsonArray jsonArray = element.getAsJsonArray();
            // Example: Loop through array items
            for (JsonElement item : jsonArray) {
                System.out.println("Item: " + item.getAsString());
            }
        } else {
            System.out.println("Unsupported JSON format");
        }
    }
}
