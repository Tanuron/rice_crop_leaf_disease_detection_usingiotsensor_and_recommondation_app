package com.example.rice.models;
import java.util.List;

import java.util.List;

public class WeatherResponse {
    private Main main;
    private List<Weather> weather;

    // Getter and setter for the main temperature data
    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    // Getter and setter for the weather list
    public List<Weather> getWeather() {
        return weather;
    }

    public void setWeather(List<Weather> weather) {
        this.weather = weather;
    }
}
