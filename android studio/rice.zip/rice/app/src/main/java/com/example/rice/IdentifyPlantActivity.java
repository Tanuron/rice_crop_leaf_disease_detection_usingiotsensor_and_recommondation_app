package com.example.rice;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class IdentifyPlantActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identify_plant);

        // Populate Disease Data
        populateDiseaseDetails(
                R.id.plant_image_1, R.drawable.brown_spot,
                R.id.plant_details_1,
                "Brown Spot",
                "- Minute brown dots develop into cylindrical or circular spots.\n" +
                        "- Coalescing spots cause leaf drying.\n" +
                        "- Infection occurs on panicle and neck.\n" +
                        "- Yield reduction up to 50% in severe cases.\n\n" +
                        "Mode of Spread:\n" +
                        "- Infected seeds, volunteer rice, and airborne spores.\n" +
                        "- Common in nutrient-deficient soils.\n\n" +
                        "Favorable Conditions:\n" +
                        "- Temperature 25-30°C and high humidity (80%+).\n" +
                        "- Wet leaves for 8-24 hours.",
                R.id.plant_button_1, "Carbendazim 50% WP or Mancozeb 75% WP.",
                "https://www.example.com/buy-brown-spot-pesticide"
        );

        populateDiseaseDetails(
                R.id.plant_image_2, R.drawable.leaf_blast,
                R.id.plant_details_2,
                "Leaf Blast",
                "- White to gray-green lesions with brown borders.\n" +
                        "- Spindle-shaped spots with ashy centers on leaves.\n" +
                        "- Neck blast causes panicle breakage.\n" +
                        "- Severe cases resemble burnt crops.\n\n" +
                        "Favorable Conditions:\n" +
                        "- Cloudy skies, high humidity (90%+), wet leaves.\n" +
                        "- High nitrogen levels (e.g., ammonium sulfate).\n" +
                        "- Temperature 25-28°C.",
                R.id.plant_button_2, "Tricyclazole 75% WP or Isoprothiolane 40% EC.",
                "https://www.example.com/buy-leaf-blast-pesticide"
        );

        populateDiseaseDetails(
                R.id.plant_image_3, R.drawable.tungro,
                R.id.plant_details_3,
                "Rice Tungro Disease",
                "- Yellow-orange discoloration and stunted growth.\n" +
                        "- Reduced tillering and delayed flowering.\n" +
                        "- Panicles small, partially filled, or sterile.\n\n" +
                        "Spread:\n" +
                        "- Transmitted by leafhoppers, mainly Nephotettix virescens.\n" +
                        "- Associated with two viruses: RTBV and RTSV.\n\n" +
                        "Favorable Conditions:\n" +
                        "- Presence of vector, virus, and susceptible host plants.",
                R.id.plant_button_3, "Imidacloprid 17.8% SL to control leafhoppers.",
                "https://www.example.com/buy-tungro-pesticide"
        );

        populateDiseaseDetails(
                R.id.plant_image_4, R.drawable.bacteria_leaf_blight,
                R.id.plant_details_4,
                "Bacterial Leaf Blight",
                "- Seedling wilt or kresek observed 1-3 weeks after transplanting.\n" +
                        "- Water-soaked to yellowish stripes on leaf blades.\n" +
                        "- Bacterial ooze visible as milky dewdrops.\n" +
                        "- Yield loss up to 60% in severe cases.\n\n" +
                        "Favorable Conditions:\n" +
                        "- Warm temperature (25-30°C), high humidity, rain, and deep water.\n" +
                        "- Presence of weeds, rice stubbles, and ratoons.",
                R.id.plant_button_4, "Streptomycin sulfate 90% SP mixed with Copper oxychloride 50% WP.",
                "https://www.example.com/buy-bacterial-leaf-blight-pesticide"
        );
    }

    /**
     * Helper function to populate disease details dynamically.
     */
    private void populateDiseaseDetails(int imageViewId, int imageResId,
                                        int textViewId, String diseaseName, String diseaseDetails,
                                        int buttonId, String pesticide, String purchaseLink) {
        ImageView plantImage = findViewById(imageViewId);
        TextView plantDetails = findViewById(textViewId);
        Button plantButton = findViewById(buttonId);

        // Set the image and details
        plantImage.setImageResource(imageResId);
        plantDetails.setText("Disease Name: " + diseaseName + "\n\n" + diseaseDetails);

        // Set up button click to show pesticide dialog
        plantButton.setOnClickListener(view -> showPesticideDialog(diseaseName, pesticide, purchaseLink));
    }

    /**
     * Function to show pesticide recommendation dialog with a purchase link.
     */
    private void showPesticideDialog(String diseaseName, String pesticide, String purchaseLink) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pesticide Recommendation for " + diseaseName);
        builder.setMessage("Recommended Pesticide:\n" + pesticide + "\n\n" +
                "You can purchase it online. Click 'Buy Now' to proceed.");

        builder.setPositiveButton("Buy Now", (dialog, which) -> {
            try {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(purchaseLink));
                startActivity(browserIntent);
            } catch (Exception e) {
                Toast.makeText(IdentifyPlantActivity.this, "Unable to open the link.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Close", null);

        // Show the dialog
        builder.show();
    }
}
