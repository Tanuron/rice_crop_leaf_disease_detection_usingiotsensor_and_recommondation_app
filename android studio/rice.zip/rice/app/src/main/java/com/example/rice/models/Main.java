package com.example.rice.models;

public class Main {
    private double temp;

    public double getTemp() { return temp; }
}

