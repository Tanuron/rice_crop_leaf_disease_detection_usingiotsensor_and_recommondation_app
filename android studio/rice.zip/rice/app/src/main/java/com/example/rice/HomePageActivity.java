package com.example.rice;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.provider.MediaStore;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.ArrayList;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.widget.ProgressBar;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.MediaType;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.io.File;

import java.io.IOException;

import android.location.Location;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.example.rice.models.WeatherResponse;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

public class HomePageActivity extends AppCompatActivity {
    private ProgressBar progressBar;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 100;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 101;
    private static final int CAMERA_REQUEST_CODE = 102;
    private static final int GALLERY_REQUEST_CODE = 103;
    private static final String WEATHER_API_KEY = "7dffd68bb0e6c6f18c608170ba825b79";  // Replace with your API key
    private Button dashboardButton, logoutButton, cameraButton;
    private FusedLocationProviderClient fusedLocationClient;
    private TextView weatherTextView;
    private ImageView weatherIcon;
    private File imageFile;
    private ApiService apiService;
    private Button fetchPredictionsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        initializeUI();
        initializeLocationClient();
        // Fetch stored predictions

        apiService = ApiClient.getClient().create(ApiService.class);
        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the fetch button
        fetchPredictionsButton = findViewById(R.id.btn_iot_history);

        // Set up the button listener
        fetchPredictionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the method to fetch predictions
                fetchStoredPredictions();
            }
        });

        // Initialize other buttons if necessary
        setUpButtonListeners();
    }

    private void initializeUI() {
        progressBar = findViewById(R.id.progressBar);
        dashboardButton = findViewById(R.id.btn_dashboard);
        logoutButton = findViewById(R.id.btn_logout);
        cameraButton = findViewById(R.id.btn_camera);
        weatherTextView = findViewById(R.id.weatherTextView);
        weatherIcon = findViewById(R.id.weatherIcon);
    }

    private void initializeLocationClient() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Check and request location permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            fetchLocationWithUpdates(); // Permission granted, start fetching location
        }
    }

    private void setUpButtonListeners() {
        dashboardButton.setOnClickListener(v -> openDashboard());
        logoutButton.setOnClickListener(v -> logout());
        cameraButton.setOnClickListener(v -> checkCameraPermissionAndOpen());

        // Gallery button listener
        findViewById(R.id.btn_gallery).setOnClickListener(v -> openGallery());
    }

    private void openDashboard() {
        startActivity(new Intent(HomePageActivity.this, DashboardActivity.class));
    }

    private void logout() {
        startActivity(new Intent(HomePageActivity.this, LoginActivity.class));
        finish();
    }

    private void checkCameraPermissionAndOpen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
        } else {
            openCamera();
        }
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE);
    }

    private void fetchLocationWithUpdates() {
        LocationRequest locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10000)
                .setFastestInterval(5000);

        LocationCallback locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult != null && !locationResult.getLocations().isEmpty()) {
                    Location location = locationResult.getLastLocation();
                    fetchWeatherData(location.getLatitude(), location.getLongitude());
                }
            }
        };

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        } else {
            Toast.makeText(this, "Location permission is required", Toast.LENGTH_SHORT).show();
        }
    }

    private void fetchWeatherData(double latitude, double longitude) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        WeatherService service = retrofit.create(WeatherService.class);
        Call<WeatherResponse> call = service.getWeather(latitude, longitude, WEATHER_API_KEY);

        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    updateWeatherUI(response.body());
                } else {
                    weatherTextView.setText("Unable to fetch weather data.");
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                weatherTextView.setText("Error fetching weather data.");
                t.printStackTrace();
            }
        });
    }

    private void updateWeatherUI(WeatherResponse weatherData) {
        double tempInKelvin = weatherData.getMain().getTemp();
        double tempInCelsius = tempInKelvin - 273.15;

        String weatherInfo = "Temperature: " + String.format("%.2f", tempInCelsius) + "°C\n"
                + "Condition: " + weatherData.getWeather().get(0).getDescription();
        weatherTextView.setText(weatherInfo);

        String iconCode = weatherData.getWeather().get(0).getIcon();
        setWeatherIcon(iconCode);
    }

    private void setWeatherIcon(String iconCode) {
        String iconUrl = "https://openweathermap.org/img/wn/" + iconCode + "@2x.png";
        Glide.with(this).load(iconUrl).into(weatherIcon);
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            try {
                imageFile = createImageFile();
                Uri photoUri = FileProvider.getUriForFile(this, "com.example.rice.fileprovider", imageFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Error creating image file", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No camera app found", Toast.LENGTH_SHORT).show();
        }
    }

    private File createImageFile() throws IOException {
        String fileName = "captured_image";
        File storageDir = getExternalFilesDir(null);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            if (imageFile != null) {
                sendImageToBackend(imageFile);
            }
        } else if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                try {
                    File galleryFile = getFileFromUri(selectedImageUri);
                    sendImageToBackend(galleryFile);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error selecting image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private File getFileFromUri(Uri uri) throws IOException {
        String fileName = "gallery_image";
        File storageDir = getExternalFilesDir(null);
        File tempFile = File.createTempFile(fileName, ".jpg", storageDir);

        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             FileOutputStream outputStream = new FileOutputStream(tempFile)) {

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
        }

        return tempFile;
    }

    private void sendImageToBackend(File file) {
        progressBar.setVisibility(View.VISIBLE);

        Retrofit retrofit = ApiClient.getClient();
        ApiService apiService = retrofit.create(ApiService.class);

        RequestBody requestBody = RequestBody.create(MediaType.parse("image/jpeg"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(), requestBody);

        apiService.uploadImageAndGetPrediction(body).enqueue(new Callback<PredictionResponse>() {
            @Override
            public void onResponse(Call<PredictionResponse> call, Response<PredictionResponse> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    PredictionResponse predictionResponse = response.body();
                    sendPredictionResult(predictionResponse);
                } else {
                    Toast.makeText(HomePageActivity.this, "Prediction failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PredictionResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(HomePageActivity.this, "Error uploading image", Toast.LENGTH_SHORT).show();
                t.printStackTrace();
            }
        });
    }

    private void sendPredictionResult(PredictionResponse predictionResponse) {
        // Create an intent to start the ReturnActivity
        Intent intent = new Intent(HomePageActivity.this, ReturnActivity.class);

        // Extract data from PredictionResponse
        String prediction = predictionResponse.getPrediction();
        float confidence = predictionResponse.getConfidence();
        List<String> pesticides = predictionResponse.getPesticides();
        List<String> precautions = predictionResponse.getPrecautions();

        // Add the extracted data to the intent
        intent.putExtra("prediction", prediction);
        intent.putExtra("confidence", confidence);

        // Convert List<String> to ArrayList<String> and add to the intent
        intent.putExtra("pesticides", new ArrayList<>(pesticides));
        intent.putExtra("precautions", new ArrayList<>(precautions));

        // Start ReturnActivity
        startActivity(intent);
    }

    private void fetchStoredPredictions() {
        // Make the API call to fetch predictions with timestamp
        Call<List<PredictionWithTimestampResponse>> call = apiService.getPredictionsWithTimestamp();

        call.enqueue(new Callback<List<PredictionWithTimestampResponse>>() {
            @Override
            public void onResponse(Call<List<PredictionWithTimestampResponse>> call, Response<List<PredictionWithTimestampResponse>> response) {
                if (response.isSuccessful()) {
                    List<PredictionWithTimestampResponse> predictions = response.body();
                    if (predictions != null) {
                        // Handle the predictions data with timestamp
                        updateUIWithPredictions(predictions);
                    } else {
                        Toast.makeText(HomePageActivity.this, "No predictions available", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.e("API_ERROR", "Response failed: " + response.message());
                    Toast.makeText(HomePageActivity.this, "Error fetching predictions", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<PredictionWithTimestampResponse>> call, Throwable t) {
                Log.e("API_ERROR", "Request failed: " + t.getMessage());
                Toast.makeText(HomePageActivity.this, "Failed to fetch predictions", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void updateUIWithPredictions(List<PredictionWithTimestampResponse> predictions) {
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        PredictionAdapter adapter = new PredictionAdapter((List<Object>) (List<?>) predictions);  // Cast list to Object
        recyclerView.setAdapter(adapter);
    }







}
