package com.example.rice;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ApiClient {

    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        if (retrofit == null) {
            Gson gson = new GsonBuilder()
                    .registerTypeAdapter(Object.class, new PesticidesAdapter()) // Register custom adapter
                    .create();

            retrofit = new Retrofit.Builder()
                    .baseUrl("https://dbf1-2409-40f2-3056-2fde-5857-fa69-41cf-4dde.ngrok-free.app/") // Django backend URL
                    .addConverterFactory(GsonConverterFactory.create(gson)) // Use custom Gson instance
                    .build();
        }
        return retrofit;
    }
}
