package com.example.rice;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private Button plantCareButton, identifyPlantButton, backButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        plantCareButton = findViewById(R.id.btn_plant_care);
        identifyPlantButton = findViewById(R.id.btn_identify_plant);
        backButton = findViewById(R.id.btn_back_to_home);
        logoutButton = findViewById(R.id.btn_logout);

        plantCareButton.setOnClickListener(v -> {
            // Navigate to Plant Care Tips Activity
            Intent intent = new Intent(DashboardActivity.this, PlantCareTipsActivity.class);
            startActivity(intent);
        });

        identifyPlantButton.setOnClickListener(v -> {
            // Navigate to Identify Plant Activity
            Intent intent = new Intent(DashboardActivity.this, IdentifyPlantActivity.class);
            startActivity(intent);
        });

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, HomePageActivity.class);
            startActivity(intent);
            finish();
        });

        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}