package com.example.rice;

import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DatabaseActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PredictionAdapter adapter;
    private List<Object> predictionsList = new ArrayList<>();  // List to handle both types

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Get the predictions passed from HomePageActivity
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("predictions")) {
            predictionsList = (List<Object>) intent.getSerializableExtra("predictions");  // Casting to List<Object>
            adapter = new PredictionAdapter(predictionsList);
            recyclerView.setAdapter(adapter);
        }
    }
}
