package com.example.rice;

// PesticidesDeserializer.java
import com.google.gson.*;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;

public class PesticidesDeserializer implements JsonDeserializer<List<String>> {
    @Override
    public List<String> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        if (json.isJsonArray()) {
            // Return the array as a list of strings
            return Arrays.asList(new Gson().fromJson(json, String[].class));
        } else if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isString()) {
            // If it's a single string, return it as a list
            return Arrays.asList(json.getAsString());
        }
        return null;
    }
}
