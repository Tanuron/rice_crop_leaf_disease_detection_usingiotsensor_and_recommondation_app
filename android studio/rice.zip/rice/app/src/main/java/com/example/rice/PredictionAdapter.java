package com.example.rice;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PredictionAdapter extends RecyclerView.Adapter<PredictionAdapter.ViewHolder> {
    private final List<Object> predictions;  // Can handle both types

    public PredictionAdapter(List<Object> predictions) {
        this.predictions = predictions;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_prediction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Object predictionObj = predictions.get(position);

        if (predictionObj instanceof PredictionResponse) {
            PredictionResponse prediction = (PredictionResponse) predictionObj;
            // Bind data for PredictionResponse
            holder.predictionTextView.setText(prediction.getPrediction());
            holder.confidenceTextView.setText(String.format("Confidence: %.2f", prediction.getConfidence()));
            holder.pesticidesTextView.setText("Pesticides: " + formatPesticides(prediction.getPesticides()));
            holder.precautionsTextView.setText("Precautions: " + formatList(prediction.getPrecautions()));
            holder.timestampTextView.setText("Timestamp: Not available");
        } else if (predictionObj instanceof PredictionWithTimestampResponse) {
            PredictionWithTimestampResponse prediction = (PredictionWithTimestampResponse) predictionObj;
            // Bind data for PredictionWithTimestampResponse
            holder.predictionTextView.setText(prediction.getPrediction());
            holder.confidenceTextView.setText(String.format("Confidence: %.2f", prediction.getAverage_confidence()));
            holder.pesticidesTextView.setText("Pesticides: " + formatPesticides(prediction.getPesticides()));
            holder.precautionsTextView.setText("Precautions: " + prediction.getPrecautions());
            holder.timestampTextView.setText("Timestamp: " + prediction.getTimestamp());
        }
    }

    @Override
    public int getItemCount() {
        return predictions.size();
    }

    // Helper method to format pesticides (either a string or a list)
    private String formatPesticides(Object pesticides) {
        if (pesticides instanceof String) {
            return (String) pesticides;
        } else if (pesticides instanceof List) {
            return formatList((List<String>) pesticides);
        }
        return "No data available";
    }

    // Helper method to format lists of precautions or other lists
    private String formatList(List<String> list) {
        if (list == null || list.isEmpty()) {
            return "No data available";
        } else {
            return String.join(", ", list);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView predictionTextView;
        TextView confidenceTextView;
        TextView pesticidesTextView;
        TextView precautionsTextView;
        TextView timestampTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            predictionTextView = itemView.findViewById(R.id.predictionTextView);
            confidenceTextView = itemView.findViewById(R.id.confidenceTextView);
            pesticidesTextView = itemView.findViewById(R.id.pesticidesTextView);
            precautionsTextView = itemView.findViewById(R.id.precautionsTextView);
            timestampTextView = itemView.findViewById(R.id.timestampTextView);
        }
    }
}
