package com.example.rice;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import com.example.rice.models.WeatherResponse;  // Adjust package if necessary

public interface WeatherService {
    @GET("weather")
    Call<WeatherResponse> getWeather(
            @Query("lat") double latitude,
            @Query("lon") double longitude,
            @Query("appid") String apiKey
    );
}
