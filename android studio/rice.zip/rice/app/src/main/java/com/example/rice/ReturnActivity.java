
package com.example.rice;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ReturnActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result); // Ensure you have the correct layout file for ReturnActivity

        // Retrieve data passed from HomePageActivity via Intent
        String prediction = getIntent().getStringExtra("prediction");
        float confidence = getIntent().getFloatExtra("confidence", 0f);
        ArrayList<String> pesticides = getIntent().getStringArrayListExtra("pesticides");
        ArrayList<String> precautions = getIntent().getStringArrayListExtra("precautions");

        // Display the data in the UI (TextViews or other elements)
        TextView predictionText = findViewById(R.id.textPrediction);
        TextView confidenceText = findViewById(R.id.textConfidence);
        TextView pesticidesText = findViewById(R.id.textPesticides);
        TextView precautionsText = findViewById(R.id.textPrecautions);

        // Set the prediction and confidence text
        if (prediction != null) {
            predictionText.setText("Prediction: " + prediction);
        } else {
            predictionText.setText("Prediction: N/A");
        }

        confidenceText.setText("Confidence: " + confidence + "%");

        // Format the pesticides section
        if (pesticides != null && !pesticides.isEmpty()) {
            StringBuilder pesticidesTextContent = new StringBuilder("Pesticides:\n");
            for (String pesticide : pesticides) {
                pesticidesTextContent.append("- ").append(pesticide).append("\n");
            }
            pesticidesText.setText(pesticidesTextContent.toString());
        } else {
            pesticidesText.setText("Pesticides: N/A");
        }

        // Format the precautions section
        if (precautions != null && !precautions.isEmpty()) {
            StringBuilder precautionsTextContent = new StringBuilder("Precautions:\n");
            for (String precaution : precautions) {
                precautionsTextContent.append("- ").append(precaution).append("\n");
            }
            precautionsText.setText(precautionsTextContent.toString());
        } else {
            precautionsText.setText("Precautions: N/A");
        }
    }
}
