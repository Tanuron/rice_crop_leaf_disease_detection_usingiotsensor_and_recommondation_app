package com.example.rice;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class PredictionResponse implements Parcelable {
    private String prediction;
    private float confidence;
    private List<String> pesticides;
    private List<String> precautions;

    // Constructor
    public PredictionResponse(String prediction, float confidence, List<String> pesticides, List<String> precautions) {
        this.prediction = prediction;
        this.confidence = confidence;
        this.pesticides = pesticides;
        this.precautions = precautions;
    }

    // Getters and Setters
    public String getPrediction() {
        return prediction;
    }

    public void setPrediction(String prediction) {
        this.prediction = prediction;
    }

    public float getConfidence() {
        return confidence;
    }

    public void setConfidence(float confidence) {
        this.confidence = confidence;
    }

    public List<String> getPesticides() {
        return pesticides;
    }

    public void setPesticides(List<String> pesticides) {
        this.pesticides = pesticides;
    }

    public List<String> getPrecautions() {
        return precautions;
    }

    public void setPrecautions(List<String> precautions) {
        this.precautions = precautions;
    }

    // Parcelable implementation
    protected PredictionResponse(Parcel in) {
        prediction = in.readString();
        confidence = in.readFloat();
        pesticides = in.createStringArrayList();
        precautions = in.createStringArrayList();
    }

    public static final Creator<PredictionResponse> CREATOR = new Creator<PredictionResponse>() {
        @Override
        public PredictionResponse createFromParcel(Parcel in) {
            return new PredictionResponse(in);
        }

        @Override
        public PredictionResponse[] newArray(int size) {
            return new PredictionResponse[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(prediction);
        dest.writeFloat(confidence);
        dest.writeStringList(pesticides);
        dest.writeStringList(precautions);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
