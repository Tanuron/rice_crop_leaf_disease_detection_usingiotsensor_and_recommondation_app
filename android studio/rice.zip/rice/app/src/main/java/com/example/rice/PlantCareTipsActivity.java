package com.example.rice;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class PlantCareTipsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_care_tips);  // Ensure this layout file exists
    }
}